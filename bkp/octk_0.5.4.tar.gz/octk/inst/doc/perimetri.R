## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(octk)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  progetti <- load_progetti(bimestre = "20180630", visualizzati = TRUE, light = TRUE, debug = TRUE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # la prima volta che si eseuge il flusso:
#  
#  setup_query_xls()
#  # salva template di "query_input.xlsx" in TEMP (da popolare manualmente)
#  # salva anche "stoplist.csv", "safelist.csv", "fixlist.csv" (descritte dopo)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # lista delle query da eseguire
#  lista_query <- c("query_cup",  "query_ue", "query_po", "query_cipe",
#                   "query_strum", "query_progcomp", "query_patt",
#                   "query_ra", "query_atp", "query_qsn", "query_tipo_cup",
#                   "query_comuni", "query_beniconf",
#                   "query_keyword")
#  
#  # esecuzione query
#  pseudo <- make_pseudo_edit(progetti, query_ls=lista_query, export=TRUE)
#  
#  # integrazione con lista progetti predefinita
#  pseudo <- add_to_pseudo(pseudo, addendum = "progetti_da_aggiungere.csv", add_name="QUERY_ADD", export = TRUE)
#  
#  # integrazione con lista progetti da altro perimetro e relative classi
#  pseudo <- add_perimetro_to_pseudo(pseudo, addendum = "Idrico_clp.csv", usa_classi=TRUE, export = TRUE)
#  
#  # perimetrazione
#  pseudo <- make_perimetro_edit(pseudo, progetti=progetti, export=TRUE, debug=TRUE)
#  
#  # verifica perimetro
#  # chk_dupli_perimetro(pseudo)
#  # TODO:
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # setup classi
#  setup_classi_cup(pseudo, progetti, "classi_cup.csv")
#  setup_classi_ue(pseudo, progetti, "classi_ue.csv")
#  # HAND: integrare classi_cup.csv, classi_ue.csv e fixlist.csv
#  # TODO: inserire tool per gestire integrazione da bimestre precedenti
#  
#  # classificazione
#  pseudo <- make_classi(pseudo,
#                        classe_jolly="Turismo",
#                        livelli_classe = c("Natura", "Cultura", "Turismo"),
#                        export=TRUE, debug=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # classificazione
#  pseudo <- make_classi_hard_soft(pseudo, export=TRUE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # setup classi
#  setup_classi_soggetti("classi_soggetti.csv")
#  # HAND: integrare classi_soggetti.csv
#  
#  # classificazione
#  pseudo <- make_classi_soggetti(pseudo, livelli_classe=NULL, progetti, export = TRUE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # classificazione
#  pseudo <- make_classi_comuni(pseudo, progetti=progetti, export = TRUE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # integra ed esporta in csv
#  perimetro <- export_data(pseudo, focus, bimestre, var_ls=NULL, var_add=NULL, export=TRUE)
#  
#  # esporta in xls
#  export_data_xls(perimetro, focus, bimestre, use_template=FALSE)
#  
#  # esporta per flusso SAS
#  export_sas(perimetro, focus="perimetro", use_drive=TRUE, keep_classe=FALSE, split_classe=FALSE)
#  
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # lista report di interesse
#  report_ls <- c("report_cicli_temi", "report_cicli_ambiti", "report_regioni", "report_dimensioni", "report_stati")
#  
#  # clp per progetti di interesse
#  clp_csv <- perimetro %>% select(COD_LOCALE_PROGETTO, CLASSE, AMBITO)
#  
#  # esportazione
#  workflow_report(clp_csv, report_ls=NULL, progetti=NULL, use_coe=TRUE, operazioni=NULL,
#                  tema=NULL, livelli_tema=NULL, nome_file=NULL, use_template=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # nei successivi aggiornamenti:
#  
#  # definisce versione precedente per il confronto
#  OLD <- file.path(DRIVE, "ELAB", "20201231",  "PERIMETRI", "Turismo", "V.01")
#  
#  # salva "input_query_delta.xlsx" in TEMP con solo le nuove righe (da popolare manualmente)
#  make_input_delta(OLD)
#  
#  # accoda "input_query_delta.xlsx" al precedente "query_input.xlsx"
#  update_input_with_delta(OLD)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # path per il precedente perimetro
#  # OLD <-"G:/Drive condivisi/ELAB/20201231/PERIMETRI/Turismo/V.02/temp/Turismo_20201231.csv"
#  OLD <- file.path(DRIVE, "ELAB", "20201231", "PERIMETRI", "Turismo", "V.01", "temp", "Turismo_20201231.csv")
#  
#  
#  # isola delta
#  delta <- make_delta(perimetro, path_to_old = OLD, debug=TRUE)
#  
#  # isola delta di scarti
#  var_ls <- c("COD_LOCALE_PROGETTO", "OC_TITOLO_PROGETTO", "OC_FINANZ_TOT_PUB_NETTO", "COD_RISULTATO_ATTESO")
#  delta_scarti <- make_delta_scarti(pseudo, perimetro, path_to_old = OLD, debug=TRUE, var_ls, min_cp=2000000)
#  

