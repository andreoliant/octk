## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # Parametri di setup
#  bimestre <- "20180630"         # Bimestre OC di riferimento
#  focus <- "turismo"             # Prefisso per i file da esportare
#  workarea <- "/path/to/project" # Path della workarea (es. progetto RStudio)
#  data_path <- "/path/to/data"   # Path dei dati
#  
#  # Library
#  # install.packages("devtools")
#  devtools::load_all(path = "/path/to/oc")

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # Elenco delle variabili di OC (sono riportate nel file dati esteso)
#  var_ls <- c("COD_LOCALE_PROGETTO", "CUP", "OC_TITOLO_PROGETTO",
#              "OC_COD_CICLO", "OC_COD_FONTE", "FONDO_COMUNITARIO",
#              "CUP_COD_SETTORE",  "CUP_DESCR_SETTORE",
#              "CUP_COD_SOTTOSETTORE", "CUP_DESCR_SOTTOSETTORE",
#              "CUP_COD_CATEGORIA", "CUP_DESCR_CATEGORIA",
#              "OC_DESCRIZIONE_PROGRAMMA", "OC_CODICE_PROGRAMMA",
#              "OC_COD_ARTICOLAZ_PROGRAMMA", "OC_DESCR_ARTICOLAZ_PROGRAMMA",
#              "OC_COD_SUBARTICOLAZ_PROGRAMMA", "OC_DESCR_ARTICOLAZ_PROGRAMMA",
#              "OC_FINANZ_TOT_PUB_NETTO", "IMPEGNI", "TOT_PAGAMENTI")
#  
#  # Livelli di riferimento per la variabile CLASSE
#  livelli_classe <- c("Natura", "Cultura", "Turismo")

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  progetti <- load_progetti(bimestre = "20180630", visualizzati = TRUE, debug = TRUE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  write.csv2(categorie_cup, file.path(INPUT, "categorie_cup.csv"), row.names = FALSE)
#  write.csv2(categorie_ue, file.path(INPUT, "categorie_ue.csv"), row.names = FALSE)
#  write.csv2(po_linee_azioni, file.path(INPUT, "po_linee_azioni.csv"), row.names = FALSE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  peri_cup <- query_cup(progetti)
#  peri_po <- query_po(progetti)
#  peri_ue <- query_ue(progetti)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # creazione manuale di pseudo:
#  pseudo <- peri_cup %>%
#      full_join(peri_po) %>%
#      full_join(peri_ue)
#  write.csv2(pseudo, file.path(TEMP, "pseudo.csv"), row.names = FALSE)
#  
#  # creazione di pseudo con il wrapper standard:
#  pseudo <- make_pseudo_std(progetti, export=TRUE)
#  # MEMO: usa le 3 query
#  
#  # creazione di pseudo con il wrapper editabile:
#  pseudo <- make_pseudo_edit(progetti, query_ls=c("query_cup", "query_po"), export=TRUE)
#  # MEMO: seleziona le query desiderate
#  
#  # ricarica pseudo (ad es. in una nuova sessione)
#  pseudo <- read_csv2(file.path(TEMP, "pseudo.csv"))

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # Integrazione progetti turismo da precedente metodologia
#  pseudo <- add_old_turismo(pseudo, export=TRUE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  write.csv2(stoplist, file.path(INPUT, "stoplist.csv"), row.names = FALSE)
#  write.csv2(safelist, file.path(INPUT, "safelist.csv"), row.names = FALSE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  pseudo <- make_perimetro(pseudo, export=TRUE, debug=TRUE)
#  # DEV: qui va fatto anche blocco per query editabili

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  pseudo <- make_classi(pseudo,
#                        classe_jolly="Turismo",
#                        livelli_classe = c("Natura", "Cultura", "Turismo"),
#                        export=TRUE, debug=FALSE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  perimetro <- export_data(pseudo, focus, bimestre, var_ls, var_add=NULL, chk_today="20180731")

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  export_report(perimetro, use_template=TRUE)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  delta <- make_delta(perimetro, path_to_old = OLD, debug=TRUE)
#  # chk_match(perimetro, delta, id="COD_LOCALE_PROGETTO")
#  # chk_match(perimetro, perim_old, id="COD_LOCALE_PROGETTO")
#  chk_delta(perimetro, path_to_old = OLD, debug=TRUE)
#  make_delta_scarti(pseudo, perimetro, path_to_old = OLD, debug=TRUE, var_ls, min_cp=2000000)

