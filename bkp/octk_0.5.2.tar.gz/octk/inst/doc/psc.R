## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  library(octk)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # carica file di supporto e crea variabile PSC con path ai dati di base
#  init_psc()
#  
#  
#  # dati sgp per 2000-2006
#  prep_dati_sgp_bimestre(bimestre = "20210430",
#                         filename = "Estrazioni dati e calcolo indicatori_XXXXXX.xlsx",
#                         matrix_06,
#                         chk_today = "2021-04-30") # data di riferimento per il calcolo dello stato procedurale
#  # Se mancano i dati sgp del bimestre si copia il bimestre precedente:
#  # file.copy(file.path(PSC, "sgp", "dati_sgp_20210228.csv"), file.path(PSC, "sgp", "dati_sgp_20210430.csv"), overwrite = TRUE)
#  
#  
#  # dati bimestre per tre cicli
#  prep_dati_psc_bimestre(bimestre = "20210430", matrix, po_naz, art44, matrix_1420, matrix_713, matrix_temi_settori)
#  
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # caricamento de, dataset attuazione PSC
#  progetti_psc <- load_progetti_psc(bimestre)
#  
#  # report con apertura per psc e po di origine
#  report1 <- make_report_report_po_psc(progetti_psc, programmazione=NULL, visualizzati=TRUE, export=TRUE, export_xls=FALSE)
#  
#  # report con apertura per psc e temi
#  report2 <- make_report_report_temi_psc(progetti_psc, programmazione=NULL, visualizzati=TRUE, export=TRUE, export_xls=FALSE)
#  
#  

