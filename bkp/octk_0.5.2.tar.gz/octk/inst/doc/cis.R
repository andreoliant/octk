## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(octk)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # Caricamento del dataset dal DBe della programmazione
#  interventi <- load_db_interventi(tipo = "CIS", simplify_loc=FALSE, use_temi=FALSE, use_sog=FALSE,
#                                   use_ue=FALSE, use_flt=FALSE, use_articolaz=FALSE, use_location=FALSE,
#                                   use_ciclo=TRUE, tipo_ciclo="CICLO_STRATEGIA")
#  
#  
#  # Report con aggregati per cis (in risorse coesione)
#  report_cis(interventi, lista_clp=NULL, operazioni=NULL, export=TRUE)
#  
#  
#  # Report con aggregati per cis e titolare (in risorse coesione)
#  report_cis_titolari(interventi, lista_clp=NULL, operazioni=NULL, export=TRUE)
#  
#  
#  # Report con dettaglio per cis, titolare e intervento (in risorse coesione)
#  report_cis_interventi(interventi, lista_clp=NULL, operazioni=NULL, export=TRUE)
#  
#  
#  # Report con aggregati per cis (in risorse totali)
#  report_cis_totali(interventi, lista_clp=NULL, progetti=NULL, export=TRUE)
#  
#  # Lista interventi cis con mapping a operazioni
#  lista_cis_interventi_operazioni(interventi, lista_clp=NULL, operazioni=NULL, progetti=NULL, export=TRUE)
#  # MEMO: questa è utile per finalità di debug e confronto con uffici
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # Workflow per analisi CIS
#  workflow_cis(bimestre, interventi=NULL, operazioni=NULL, progetti=NULL, debug=TRUE, export=TRUE)
#  
#  

