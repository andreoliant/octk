## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(octk)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # variazioni risorse per programmi
#  OLD <- file.path(getwd(), "20191231", "STATO", "stato", "V.01", "temp", "report_meuro_programmi_cp2.csv")
#  chk <- chk_variazione_risorse_programmi(programmi_new=programmi_2, programmi_old=NULL,
#                                   path_to_new=NULL, path_to_old=OLD,
#                                   export=FALSE)
#  # MEMO: confronta due dataframe risultanti da make_report_programmi_coesione(), descritto sotto
#  
#  # confronto tra ciclo contabile e ciclo strategia
#  chk <- chk_risorse_ciclo_contabile_strategia(use_flt=TRUE, force_yei=FALSE, use_eu=FALSE, export=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # bimestre <- 20201231
#  setup_operazioni(bimestre, progetti=NULL, export=FALSE, use_fix=FALSE, use_ecomix=FALSE, debug=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # caricamento del perimetro operazioni
#  # OLD: prep_perimetro_bimestre_coesione(bimestre, usa_meuro=FALSE)
#  load_operazioni(bimestre, usa_meuro=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # caricamento del DB programmazione
#  init_programmazione(use_temi=FALSE, use_sog=FALSE, use_eu=FALSE, use_flt=FALSE, use_713=FALSE, use_articolaz=FALSE, use_location=FALSE,
#                     use_ciclo=FALSE, tipo_ciclo="CICLO_STRATEGIA", use_en=FALSE)
#  
#  # report di riepilogo per ciclo, ambito e macroarea
#  make_report_risorse(ciclo=NULL, use_meuro=FALSE, use_flt=FALSE, use_eu=FALSE, force_yei=FALSE, tipo_ciclo="CICLO_STRATEGIA", export=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # report per programma
#  make_report_programmi_coesione(perimetro, usa_meuro=FALSE, use_713=FALSE, use_flt=FALSE,
#                                             add_totali=FALSE, use_cp2=FALSE, cut_no_risorse=FALSE,
#                                             tipo_ciclo="CICLO_STRATEGIA",
#                                             focus="report", export=FALSE, progetti=NULL, po_riclass=NULL)
#  
#  # confronto con bimestre precedente per programma
#  add_delta_programmi_coesione(bimestre, programmi, last_bimestre, last_data_path=NULL,
#                                           usa_meuro=FALSE, focus="delta", export=FALSE)
#  
#  # report per ciclo e ambito
#  make_report_bimestre_coesione(programmi, usa_meuro=TRUE, export=TRUE)
#  
#  # report per ciclo, ambito e macroarea
#  make_report_macroaree_coesione(risorse=NULL, perimetro=NULL, use_meuro=TRUE, export=TRUE)
#  
#  
#  # report attuazione per programmi e macroarea
#  make_report_programmi_macroaree_coesione(perimetro, usa_meuro=TRUE, use_713=TRUE, use_flt=TRUE,
#                                           add_totali=TRUE, use_cp2=TRUE, cut_no_risorse=FALSE,
#                                           tipo_ciclo="CICLO_STRATEGIA",
#                                           focus="report_DEF", export=TRUE, progetti)
#  
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  chk_allineamento_risorse <- function(report, programmi, report_macroaree, risorse=NULL)
#  chk_allineamento_costo_coe <- function(report, programmi, report_macroaree, perimetro=NULL)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  
#  # report attuazione per programmi per DEF
#  programmi_def <- make_report_programmi_coesione(operazioni_2, usa_meuro=TRUE, use_713=TRUE, use_flt=TRUE,
#                                                add_totali=TRUE, use_cp2=TRUE, cut_no_risorse=TRUE,
#                                                tipo_ciclo="CICLO_STRATEGIA",
#                                                focus="report_DEF", export=TRUE, progetti = progetti_2)
#  # MEMO: uso cut_no_risorse=TRUE per scartare programmi monitorati ma assenti lato programmazione
#  
#  #export per popolare tavole 1 e 2 del def (quadro risorse)
#  risorse_def <- make_report_risorse(use_meuro=TRUE, use_flt=TRUE, force_yei=FALSE, tipo_ciclo="CICLO_STRATEGIA", export=TRUE)
#  
#  # report attuazione per programmi e macroarea
#  make_report_programmi_macroaree_coesione(perimetro, usa_meuro=TRUE, use_713=TRUE, use_flt=TRUE,
#                                           add_totali=TRUE, use_cp2=TRUE, cut_no_risorse=TRUE,
#                                           tipo_ciclo="CICLO_STRATEGIA",
#                                           focus="report_DEF", export=TRUE, progetti)
#  

