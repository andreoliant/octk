## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(octk)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # ---------------- FUNZIONI GENERICHE ----------------
#  # caricamento di singolo file "Dati"
#  load_db()
#  
#  # caricamento di tutti i file "Dati" del DB programmazione
#  init_programmazione_dati()
#  
#  # caricamento di tutti i file "Info" del DB programmazione
#  init_info_info()
#  
#  # caricamento e pre-processing per pubblicazione su OpenCoesione
#  workflow_programmazione()
#  
#  
#  # ---------------- REPORT SPECIFICI ----------------
#  
#  # report di riepilogo per ciclo, ambito e macroarea  per caricamento pagina "risorse" su OpenCoesione
#  risorse <- make_report_risorse()
#  
#  # report di riepilogo per ciclo, ambito e macroarea con evidenza degli scambi tra cicli e ambiti
#  fonti_impieghi <- make_report_fonti_impieghi()
#  
#  # report per caricamento pagina "programmi" su OpenCoesione
#  programmi <- make_pagina_programmi()
#  
#  # report per caricamento opendata "dotazioni" su OpenCoesione
#  dotazioni <- make_opendata_dotazioni()
#  
#  # report per caricamento opendata "decisioni" su OpenCoesione
#  decisioni <- make_opendata_decisioni()
#  
#  # report per caricamento della lista dei programmi confluiti nei PSC nella pagina dedicata su OpenCoesione
#  dotazioni_popsc <- make_opendata_dotazioni_popsc()
#  decisioni_popsc <- make_opendata_decisioni_popsc()
#  
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # copia file non FSC nel nuovo folder DBCOE
#  setup_dbcoe_no_fsc(db_path_old, db_path_new=NULL)
#  
#  # setup FSC con PSC
#  setup_dbcoe_dati_fsc_po()
#  setup_dbcoe_info_fsc_po()
#  
#  # setup file solo PSC con apertura per programmi d'origine
#  setup_dbcoe_dati_fsc_popsc()
#  setup_dbcoe_info_fsc_popsc()
#  
#  # setup SIE 1420
#  #TODO: integrare nel package gli script di Nicola
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # variazione quadro risorse
#  OLD <- file.path(DRIVE, "ELAB", "20210430", "PROGRAMMAZIONE", "sito", "V.03", "temp")
#  chk <- chk_variazione_risorse_ciclo_ambito(risorse_new = risorse,
#                                      path_to_old = file.path(OLD, "risorse_coesione.csv"),
#                                      export=TRUE)
#  
#  # variazione lista programmi
#  chk <- chk_variazione_risorse_programmi(programmi_new = programmi,
#                                   path_to_old = OLD,
#                                   export = TRUE)
#  
#  # confronto tra ciclo contabile e ciclo strategia
#  chk <- chk_risorse_ciclo_contabile_strategia(use_flt=TRUE, force_yei=FALSE, use_eu=FALSE, export=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # bimestre <- 20201231
#  setup_operazioni(bimestre, progetti=NULL, export=FALSE, use_fix=FALSE, use_ecomix=FALSE, debug=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # caricamento del perimetro operazioni
#  # OLD: prep_perimetro_bimestre_coesione(bimestre, usa_meuro=FALSE)
#  load_operazioni(bimestre, usa_meuro=FALSE)
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # report per programma
#  make_report_programmi_coesione(perimetro, usa_meuro=FALSE, use_713=FALSE, use_flt=FALSE,
#                                             add_totali=FALSE, use_cp2=FALSE, cut_no_risorse=FALSE,
#                                             tipo_ciclo="CICLO_STRATEGIA",
#                                             focus="report", export=FALSE, progetti=NULL, po_riclass=NULL)
#  
#  # confronto con bimestre precedente per programma
#  add_delta_programmi_coesione(bimestre, programmi, last_bimestre, last_data_path=NULL,
#                                           usa_meuro=FALSE, focus="delta", export=FALSE)
#  
#  
#  # report per ciclo e ambito
#  make_report_bimestre_coesione(programmi, usa_meuro=TRUE, export=TRUE)
#  
#  
#  
#  # report in format standard per allegato DEF
#  # TODO: integrare funzione da script di Nicola
#  
#  # OLD:
#  # report per ciclo, ambito e macroarea
#  # make_report_macroaree_coesione(risorse=NULL, perimetro=NULL, use_meuro=TRUE, export=TRUE)
#  #
#  #
#  # report attuazione per programmi e macroarea
#  # make_report_programmi_macroaree_coesione(perimetro, usa_meuro=TRUE, use_713=TRUE, use_flt=TRUE,
#  #                                          add_totali=TRUE, use_cp2=TRUE, cut_no_risorse=FALSE,
#  #                                          tipo_ciclo="CICLO_STRATEGIA",
#  #                                          focus="report_DEF", export=TRUE, progetti)
#  
#  
#  
#  
#  
#  
#  
#  
#  
#  
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  chk_allineamento_risorse <- function(report, programmi, report_macroaree, risorse=NULL)
#  chk_allineamento_costo_coe <- function(report, programmi, report_macroaree, perimetro=NULL)
#  
#  # variazioni risorse per programmi
#  OLD <- file.path(getwd(), "20191231", "STATO", "stato", "V.01", "temp", "report_meuro_programmi_cp2.csv")
#  chk <- chk_variazione_risorse_programmi(programmi_new=programmi_2, programmi_old=NULL,
#                                   path_to_new=NULL, path_to_old=OLD,
#                                   export=FALSE)
#  # MEMO: confronta due dataframe risultanti da make_report_programmi_coesione(), descritto sotto
#  
#  
#  

