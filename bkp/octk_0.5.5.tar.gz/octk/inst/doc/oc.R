## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  # installazione da archivio disponible in locale
#  # download da DRIVE > TOOLS > OCTK > octk_X.X.X.tar.gz
#  install.packages("path/to/local/octk_X.X.X.tar.gz", repos = NULL, type="source")
#  library("octk")
#  
#  # installazione direttamente da GitHub
#  # install.packages("devtools")
#  devtools::install_github("andreoliant/oc")
#  library("octk")
#  
#  # caricamento da sorgente
#  # install.packages("devtools")
#  # download da DRIVE > TOOLS > OCTK > _src > octk_X.X.X
#  devtools::load_all(path = "path/to/local/octk")
#  # non è necessario invocare library("octk")
#  
#  
#  # per verificare la versione installata:
#  packageVersion("octk") # es. 0.4.2
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  library("octk")
#  
#  # setup per utenti già noti (con dati in Drive)
#  oc_init(
#    bimestre = "20201031",
#    db_ver = "20201231.01",
#    elab = "elaborazione",
#    focus = "elaborazione_specifica",
#    ver = "V.01",
#    use_drive = TRUE,
#    user = "Antonio"
#  )
#  
#  # setup per utenti già noti (con dati in locale)
#  oc_init(
#    bimestre = "20201031",
#    db_ver = "20201231.01",
#    elab = "elaborazione",
#    focus = "elaborazione_specifica",
#    ver = "V.01",
#    use_drive = TRUE,
#    user = "Antonio",
#    data_path = "/path/to/dati/oc" # esplicitare percorso locale
#  )
#  
#  
#  # setup per altri utenti
#  oc_init(
#    bimestre = "20201031",
#    db_ver = "20201231.01",
#    elab = "elaborazione",
#    focus = "elaborazione_specifica",
#    ver = "V.01",
#    use_drive = TRUE,
#    drive_root = "/path/to/drive/cartelle_condivise"
#  )
#  
#  

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # setuplocale
#  oc_init(
#    bimestre = "20201031",
#    db_path = "/path/to/dbcoe"
#    db_ver = "20201231.01",
#    elab = "elaborazione",
#    focus = "elaborazione_specifica",
#    ver = "V.01",
#    data_path = "/path/to/dati/oc",
#    use_drive = TRUE,
#    drive_root = "/path/to/drive/cartelle_condivise"
#  )

## ---- echo = TRUE, eval = FALSE-----------------------------------------------
#  
#  # caricamento da sorgente NIGHTLY
#  # install.packages("devtools")
#  # ROOT <- path/to/drive
#  path_to_nightly <- file.path(ROOT, "TOOLS", "OCTK", "_src", "_NIGHTLY")
#  devtools::load_all(path = path_to_nightly)
#  # non è necessario invocare library("octk")
#  

